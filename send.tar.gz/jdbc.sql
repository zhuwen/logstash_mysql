select
  *
from SMS_SEND ss
where ss.receive_time > :sql_last_value